using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PassBetweenForms
{
    public partial class frmID : Form
    {

        // add a delegate
        public delegate void IdentityUpdateHandler(object sender, IdentityUpdateEventArgs e);

        // add an event of the delegate type
        public event IdentityUpdateHandler IdentityUpdated;


        // default constructor
        public frmID()
        {
            InitializeComponent();
        }

        // close the form without raising the event
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        // raise the event
        private void btnOkay_Click(object sender, EventArgs e)
        {
            // this button click event handler will raise the 
            // event which can then intercepted by any listeners

            // read the textboxes and set the member variables
            string sNewFirst = txtFirstName.Text;
            string sNewMiddle = txtMiddleName.Text;
            string sNewLast = txtLastName.Text;

            // instance the event args and pass it each value
            IdentityUpdateEventArgs args = new IdentityUpdateEventArgs(sNewFirst,
                sNewMiddle, sNewLast);

            // raise the event with the updated arguments
            IdentityUpdated(this, args);

            this.Dispose();
        }
    }


    public class IdentityUpdateEventArgs : System.EventArgs
    {
        // add local member variable to hold text
        private string mFirstName;
        private string mMiddleName;
        private string mLastName;

        // class constructor
        public IdentityUpdateEventArgs(string sFirstName, string sMiddleName, string sLastName)
        {
            this.mFirstName = sFirstName;
            this.mMiddleName = sMiddleName;
            this.mLastName = sLastName;
        }

        // Properties - Accessible by the listener

        public string FirstName
        {
            get
            {
                return mFirstName;
            }
        }

        public string MiddleName
        {
            get
            {
                return mMiddleName;
            }
        }


        public string LastName
        {
            get
            {
                return mLastName;
            }
        }
    }
}