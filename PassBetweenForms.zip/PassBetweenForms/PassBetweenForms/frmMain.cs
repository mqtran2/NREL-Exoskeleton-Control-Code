using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PassBetweenForms
{
    public partial class frmMain : Form
    {
        // default constructor
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            // nothing to do
        }

        private void btnSetName_Click(object sender, EventArgs e)
        {
            frmID f = new frmID();

            // Add an event handler to update this form
            // when the ID form is updated (when IdentityUpdated fires).
            f.IdentityUpdated += new frmID.IdentityUpdateHandler(IdForm_ButtonClicked);

            f.Show();

        }

        // handles the event from frmId
        private void IdForm_ButtonClicked(object sender, IdentityUpdateEventArgs e)
        {
            // update the forms values from the event args
            txtFirstName.Text = e.FirstName;
            txtMiddleName.Text = e.MiddleName;
            txtLastName.Text = e.LastName;
        }


        private void btnSetAddress_Click(object sender, EventArgs e)
        {
            frmAddress f = new frmAddress();

            // Add an event handler to update this form
            // when the address form is updated (when AddressUpdated fires).
            f.AddressUpdated += new frmAddress.AddressUpdateHandler(AddressForm_ButtonClicked);

            f.Show();
        }


        // handles the event from frmAddress
        private void AddressForm_ButtonClicked(object sender, AddressUpdateEventArgs e)
        {
            // update the forms values from the event args
            txtStreet.Text = e.Street;
            txtCity.Text = e.City;
            txtState.Text = e.State;
            txtZipCode.Text = e.ZipCode;
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}