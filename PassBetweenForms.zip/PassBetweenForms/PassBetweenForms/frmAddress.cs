using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PassBetweenForms
{
    public partial class frmAddress : Form
    {
        // add a delegate
        public delegate void AddressUpdateHandler(object sender, AddressUpdateEventArgs e);

        // add an event of the delegate type
        public event AddressUpdateHandler AddressUpdated;


        public frmAddress()
        {
            InitializeComponent();
        }

        private void btnOkay_Click(object sender, EventArgs e)
        {
            // this button click event handler will raise the 
            // event which can then intercepted by any listeners

            // read the textboxes and set the member variables
            string sNewStreet = txtStreet.Text;
            string sNewCity = txtCity.Text;
            string sNewState = txtState.Text;
            string sNewZipCode = txtZipCode.Text;

            // instance the event args and pass it each value
            AddressUpdateEventArgs args = new AddressUpdateEventArgs(sNewStreet,
                sNewCity, sNewState, sNewZipCode);

            // raise the event with the updated arguments
            AddressUpdated(this, args);

            this.Dispose();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }



    public class AddressUpdateEventArgs : System.EventArgs
    {
        // add local member variables to hold text
        private string mStreet;
        private string mCity;
        private string mState;
        private string mZipCode;

        // class constructor
        public AddressUpdateEventArgs(string sStreet, string sCity,
            string sState, string sZip)
        {
            this.mStreet = sStreet;
            this.mCity = sCity;
            this.mState = sState;
            this.mZipCode = sZip;
        }

        // Properties - Viewable by each listener

        public string Street
        {
            get
            {
                return mStreet;
            }
        }

        public string City
        {
            get
            {
                return mCity;
            }
        }


        public string State
        {
            get
            {
                return mState;
            }
        }

        public string ZipCode
        {
            get
            {
                return mZipCode;
            }
        }
    }
}